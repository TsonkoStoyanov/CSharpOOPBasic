﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Xml.Serialization;

namespace BankAccount
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}
