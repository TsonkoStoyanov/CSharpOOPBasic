﻿namespace P03_WildFarm.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}