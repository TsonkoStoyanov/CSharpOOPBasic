﻿using System;
using P03_WildFarm.Core;

namespace P03_WildFarm
{
   public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
