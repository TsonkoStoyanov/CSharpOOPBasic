﻿using System;
using P01_Vehicles.Core;

namespace P01_Vehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
