﻿namespace P05_BorderControl
{
    internal interface ICreature
    {
        string Id { get; }
    }
}