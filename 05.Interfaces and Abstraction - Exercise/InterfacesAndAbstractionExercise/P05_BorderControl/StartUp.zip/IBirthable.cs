﻿namespace P05_BorderControl
{
    public interface IBirthable
    {
         string Birthdate { get; }
    }
}