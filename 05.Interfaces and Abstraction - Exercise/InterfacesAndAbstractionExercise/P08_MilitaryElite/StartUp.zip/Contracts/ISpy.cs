﻿namespace P08_MilitaryElite.Contracts
{
    public interface ISpy : ISoldier
    {
        int CodeNumber { get;}
    }
}