﻿namespace P03_Ferrari
{
    public interface IFerrari
    {
        string Driver { get; }
        string  UseBrakes();
        string  PushGas();
    }
}