﻿namespace DungeonsAndCodeWizards.Enums
{
    public enum Faction
    {
        CSharp = 1, 
        Java = 2
    }
}