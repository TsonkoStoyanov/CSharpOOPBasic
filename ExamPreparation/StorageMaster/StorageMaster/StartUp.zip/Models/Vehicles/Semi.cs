﻿namespace StorageMaster.Models.Vehicles
{
    public class Semi : Vehicle
    {
        private const int capacity = 10;

        public Semi() : base(capacity)
        {
        }
    }
}