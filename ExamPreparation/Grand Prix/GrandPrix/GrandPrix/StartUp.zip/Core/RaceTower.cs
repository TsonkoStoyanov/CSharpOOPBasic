﻿using System;
using System.Collections.Generic;


    public class RaceTower
    {
        public void SetTrackInfo(int lapsNumber, int trackLength)
        {
            throw new NotImplementedException();
        }
        public void RegisterDriver(List<string> commandArgs)
        { 
            throw new NotImplementedException();
        }

        public void DriverBoxes(List<string> commandArgs)
        { 
            throw new NotImplementedException();
        }

        public string CompleteLaps(List<string> commandArgs)
        { 
            throw new NotImplementedException();
        }

        public string GetLeaderboard()
        { 
            throw new NotImplementedException();
        }

        public void ChangeWeather(List<string> commandArgs)
        { 
            throw new NotImplementedException();
        }

    }
