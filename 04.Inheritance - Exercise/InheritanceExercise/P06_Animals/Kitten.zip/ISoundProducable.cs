﻿using System;

namespace P06_Animals
{
    public interface ISoundProducable
    {
      string ProduceSound();
    }
}